using Raylib_cs;
using System;
using System.IO;
using System.Numerics;
using System.Text.Json;
using System.Collections.Generic;

#region JSON MODELS

public class SceneData
{
    public int R { get; set; } = 255;
    public int G { get; set; } = 255;
    public int B { get; set; } = 255;
    public int A { get; set; } = 255;

    public float CameraFOV { get; set; } = 70f;
    public List<CubeData> Cubes { get; set; } = new();
}

public class CubeData
{
    public string Name { get; set; }
    public float X { get; set; }
    public float Y { get; set; }
    public float Z { get; set; }
}

#endregion

public unsafe static class Game
{
    static SceneData Scene;
    static Camera3D Camera;
    static Model CubeModel;
    static Texture2D CubeTexture;

    public unsafe static void Start(string projectName)
    {
        Raylib.InitWindow(1280, 720, projectName);
        Raylib.SetTargetFPS(60);

        // --- Load Scene JSON ---
        string scenePath = projectName + ".HavocScene";
        if (File.Exists(scenePath))
        {
            string json = File.ReadAllText(scenePath);
            Scene = JsonSerializer.Deserialize<SceneData>(json);
        }
        else
        {
            Scene = new SceneData(); // fallback
        }

        CubeTexture = Raylib.LoadTexture("Cube.png");

        // Create cube model
        Mesh cubeMesh = Raylib.GenMeshCube(1f, 1f, 1f);
        CubeModel = Raylib.LoadModelFromMesh(cubeMesh);

        // Apply texture
        Raylib.SetMaterialTexture(ref CubeModel.Materials[0], MaterialMapIndex.Diffuse, CubeTexture);


        Vector3 position = new Vector3(0, 0, 0);
        Vector2 planeSize = new Vector2(50f, 50f);
        Color planeColor = Color.White;


        // --- Setup 3D Camera ---
        Camera = new Camera3D
        {
            Position = new Vector3(10, 15, 20),
            Target = new Vector3(0, 9, 0),
            Up = Vector3.UnitY,
            FovY = Scene.CameraFOV,
            Projection = CameraProjection.Perspective
        };

        // --- Main Loop ---
        while (!Raylib.WindowShouldClose())
        {
            Raylib.BeginDrawing();
            Raylib.ClearBackground(new Color((byte)Scene.R, (byte)Scene.G, (byte)Scene.B, (byte)Scene.A));

            Raylib.BeginMode3D(Camera);

            DrawPlane(position, planeSize, planeColor);

            DrawScene();

            Raylib.EndMode3D();

            Raylib.DrawText(projectName, 10, 10, 20, Color.White);

            Raylib.EndDrawing();
        }

        // --- Cleanup ---
        Raylib.UnloadTexture(CubeTexture);
        Raylib.UnloadModel(CubeModel);
        Raylib.CloseWindow();
    }

    public static void DrawPlane(Vector3 position, Vector2 size, Color color)
    {
        Raylib.DrawPlane(position, size, color);
    }

    static void DrawScene()
    {
        if (Scene?.Cubes == null) return;

        foreach (var cube in Scene.Cubes)
        {
            // Draw cube model at cube position
            Raylib.DrawModel(CubeModel, new Vector3(cube.X, cube.Y, cube.Z), 1f, Color.White);

            // Optional: draw cube wireframe
            Raylib.DrawCubeWires(new Vector3(cube.X, cube.Y, cube.Z), 1f, 1f, 1f, Color.Black);
        }
    }
}
