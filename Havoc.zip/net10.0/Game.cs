using Raylib_cs;

public static class Game
{
    public static void Start(string ProjectName)
    {
        const int screenWidth = 1280;
        const int screenHeight = 720;

        Raylib.InitWindow(screenWidth, screenHeight, ProjectName);
        Raylib.SetTargetFPS(60);

        while (!Raylib.WindowShouldClose())
        {
            // Update
            // (put game logic here)

            // Draw
            Raylib.BeginDrawing();
            Raylib.ClearBackground(Color.Black);

            Raylib.DrawText("This game is made using Havoc!", 10, 10, 10, Color.White);

            Raylib.EndDrawing();
        }

        Raylib.CloseWindow();
    }
}