using Raylib_cs;
using System;
using System.IO;
using System.Numerics;
using System.Text.Json;
using System.Collections.Generic;
using System.Reflection;

#region JSON MODELS
public class SceneData
{
    public int R { get; set; } = 255;
    public int G { get; set; } = 255;
    public int B { get; set; } = 255;
    public int A { get; set; } = 255;

    public float CameraFOV { get; set; } = 70f;
    public List<CubeData> Cubes { get; set; } = new();

    public int CubeCount { get; set; }
    public string CubeTexture { get; set; }
}

public class CubeData
{
    public string Name { get; set; }

    public float PosX { get; set; }
    public float PosY { get; set; }
    public float PosZ { get; set; }

    public float RotX { get; set; }
    public float RotY { get; set; }
    public float RotZ { get; set; }

    public float ScaleX { get; set; } = 1;
    public float ScaleY { get; set; } = 1;
    public float ScaleZ { get; set; } = 1;

    public List<string> Scripts { get; set; } = new();

    public string TextureName { get; set; }
    public string ModelPath { get; set; }
}
#endregion

public unsafe static class Game
{
    static SceneData Scene;
    static Camera3D Camera;

    static Dictionary<string, Model> Models = new();
    static Dictionary<string, Texture2D> Textures = new();

    static string DataPath;
    static string LibsPath;

    public unsafe static void Start(string projectName)
    {
        string exeFolder = AppContext.BaseDirectory;
        DataPath = Path.Combine(exeFolder, projectName + "_Data");
        LibsPath = Path.Combine(exeFolder, projectName + "_Libs");

        AppDomain.CurrentDomain.AssemblyResolve += ResolveLibs;

        // Load Scene
        string scenePath = Path.Combine(DataPath, projectName + ".HavocScene");
        if (File.Exists(scenePath))
        {
            string json = File.ReadAllText(scenePath);
            Scene = JsonSerializer.Deserialize<SceneData>(json);
        }
        else
        {
            Scene = new SceneData();
        }

        // Init Raylib
        Raylib.InitWindow(1280, 720, projectName);
        Raylib.SetTargetFPS(60);

        Camera = new Camera3D
        {
            Position = new Vector3(10, 15, 20),
            Target = new Vector3(0, 5, 0),
            Up = Vector3.UnitY,
            FovY = Scene.CameraFOV,
            Projection = CameraProjection.Perspective
        };

        // Preload models & textures
        foreach (var cube in Scene.Cubes)
        {
            string modelPath = FindInData(cube.ModelPath);
            if (!string.IsNullOrEmpty(modelPath))
            {
                if (!Models.ContainsKey(modelPath))
                    Models[modelPath] = Raylib.LoadModel(modelPath);
            }
            else
            {
                if (!Models.ContainsKey("default_cube"))
                {
                    Mesh mesh = Raylib.GenMeshCube(1, 1, 1);
                    Models["default_cube"] = Raylib.LoadModelFromMesh(mesh);
                }
            }

            string texturePath = FindInData(cube.TextureName);
            if (!string.IsNullOrEmpty(texturePath))
            {
                if (!Textures.ContainsKey(texturePath))
                    Textures[texturePath] = Raylib.LoadTexture(texturePath);
            }
        }

        // Main loop
        while (!Raylib.WindowShouldClose())
        {
            Raylib.BeginDrawing();
            Raylib.ClearBackground(new Color((byte)Scene.R, (byte)Scene.G, (byte)Scene.B, (byte)Scene.A));

            Raylib.BeginMode3D(Camera);

            Raylib.DrawPlane(new Vector3(0, 0, 0), new Vector2(50, 50), Color.White);

            DrawScene();

            Raylib.EndMode3D();

            Raylib.DrawText(projectName, 10, 10, 20, Color.White);
            Raylib.EndDrawing();
        }

        foreach (var m in Models.Values)
            Raylib.UnloadModel(m);
        foreach (var t in Textures.Values)
            Raylib.UnloadTexture(t);

        Raylib.CloseWindow();
    }

    static void DrawScene()
    {
        if (Scene?.Cubes == null) return;

        foreach (var cube in Scene.Cubes)
        {
            Vector3 pos = new(cube.PosX, cube.PosY, cube.PosZ);
            Vector3 scale = new(cube.ScaleX, cube.ScaleY, cube.ScaleZ);

            string modelKey = FindInData(cube.ModelPath) ?? "default_cube";
            Model model = Models.ContainsKey(modelKey) ? Models[modelKey] : Models["default_cube"];

            string texKey = FindInData(cube.TextureName);
            if (!string.IsNullOrEmpty(texKey) && Textures.ContainsKey(texKey))
                Raylib.SetMaterialTexture(ref model.Materials[0], MaterialMapIndex.Diffuse, Textures[texKey]);

            Raylib.DrawModelEx(model, pos, Vector3.UnitY, cube.RotY, scale, Color.White);
        }
    }

    static string FindInData(string relativePath)
    {
        if (string.IsNullOrEmpty(relativePath)) return null;
        string fullPath = Path.Combine(DataPath, relativePath);
        if (File.Exists(fullPath)) return fullPath;

        foreach (var file in Directory.GetFiles(DataPath, Path.GetFileName(relativePath), SearchOption.AllDirectories))
            return file;

        return null;
    }

    static Assembly ResolveLibs(object sender, ResolveEventArgs args)
    {
        string dllName = new AssemblyName(args.Name).Name + ".dll";
        string dllPath = Path.Combine(LibsPath, dllName);
        if (File.Exists(dllPath))
            return Assembly.LoadFrom(dllPath);
        return null;
    }
}
